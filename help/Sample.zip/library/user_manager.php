<?php
defined('ABSPATH') or die('No direct script access allowed');

class UserManager {
    private $db;
    private $pdo;
    
    public function __construct() {
        $this->db = new Database();
        $this->pdo = $this->db->getConnection();
    }
    
    // بررسی اعتبار کاربر
    public function verifyUser($username, $password) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM MGT.Agency WHERE UserName = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user && $password == $user['PassWord'])) {
                return $user;
            }
            return false;
        } catch (PDOException $e) {
            error_log("Error verifying user: " . $e->getMessage());
            return false;
        }
    }
        
    // محاسبه روزهای باقی‌مانده از قرارداد
    public function getRemainingDays($userId) {
        try {
            $stmt = $this->pdo->prepare("SELECT contract_end FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user || !$user['contract_end']) {
                return 0;
            }
            
            $endDate = new DateTime($user['contract_end']);
            $today = new DateTime();
            
            if ($today > $endDate) {
                return 0;
            }
            
            $interval = $today->diff($endDate);
            return $interval->days;
        } catch (PDOException $e) {
            error_log("Error calculating remaining days: " . $e->getMessage());
            return 0;
        }
    }
	
	// مدیریت توکن‌های کاربر
    public function createUserToken($userId) {
        try {
            $token = bin2hex(random_bytes(32));
            $expiresAt = date('Y-m-d H:i:s', strtotime('+' . TOKEN_EXPIRY_HOURS . ' hours'));
            
            $stmt = $this->pdo->prepare("
                INSERT INTO user_tokens (user_id, token, expires_at) 
                VALUES (?, ?, ?)
            ");
            $stmt->execute([$userId, $token, $expiresAt]);
            
            return $token;
        } catch (PDOException $e) {
            error_log("Error creating user token: " . $e->getMessage());
            return null;
        }
    }
    
    // بررسی اعتبار توکن کاربر
    public function validateUserToken($token) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT u.* FROM user_tokens ut 
                JOIN users u ON ut.user_id = u.id 
                WHERE ut.token = ? AND ut.expires_at > NOW()
            ");
            $stmt->execute([$token]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error validating user token: " . $e->getMessage());
            return null;
        }
    }
 
    
    // حذف توکن کاربر
    public function deleteUserToken($token) {
        try {
            $stmt = $this->pdo->prepare("DELETE FROM user_tokens WHERE token = ?");
            return $stmt->execute([$token]);
        } catch (PDOException $e) {
            error_log("Error deleting user token: " . $e->getMessage());
            return false;
        }
    }
    
    // آپدیت اطلاعات کاربر
    public function updateUser($userId, $companyName, $maxComputers) {
        try {
            $stmt = $this->pdo->prepare("
                UPDATE users SET company_name = ?, max_computers = ? WHERE id = ?
            ");
            return $stmt->execute([$companyName, $maxComputers, $userId]);
        } catch (PDOException $e) {
            error_log("Error updating user: " . $e->getMessage());
            return false;
        }
    }

    // تمدید قرارداد کاربر
    public function renewUserContract($userId, $contractEnd) {
        try {
            $stmt = $this->pdo->prepare("
                UPDATE users SET contract_end = ?, updated_at = NOW() WHERE id = ?
            ");
            return $stmt->execute([$contractEnd, $userId]);
        } catch (PDOException $e) {
            error_log("Error renewing user contract: " . $e->getMessage());
            return false;
        }
    }
    
    public function getConnection() {
        return $this->pdo;
    }
}
?>