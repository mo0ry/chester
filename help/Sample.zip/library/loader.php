<?php
// حذف خطای مستقیم و استفاده از روش بهتر
if (!defined('ABSPATH')) {
    define('ABSPATH', dirname(__DIR__) . '/');
}

try {
    // بارگذاری تنظیمات
    $config_file = ABSPATH . 'library/config.php';
    if (!file_exists($config_file)) {
        throw new Exception('فایل پیکربندی یافت نشد');
    }
    
    require_once $config_file;
    
    // اتصال به دیتابیس
    require_once ABSPATH . 'library/database.php';
    
    try {
        $database = new Database();
    } catch (PDOException $e) {
        throw new Exception('خطا در اتصال به دیتابیس: ' . $e->getMessage());
    }
    
    // بارگذاری کلاس‌های اصلی
    require_once ABSPATH . 'library/jdf.php';
    require_once ABSPATH . 'library/user_manager.php';
	
    // تنظیمات اولیه
    $now = time();
    $request = cleaner($_REQUEST ?? []);
    $post = cleaner($_POST ?? []);
    $get = cleaner($_GET ?? []);
    
} catch (Exception $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => false, 
        'error' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

class Loader {
    private $database;
    private $userManager;
    
    public function __construct() {
        global $database;
        $this->database = $database;
        $this->userManager = new UserManager();
    }
    
    public function authenticateUser($token) {
        return $this->userManager->validateUserToken($token);
    }
    
    public function requireUser() {

        $user = $this->authenticateUser($token);
        
        if (!$user) {
            $this->jsonResponse(['success' => false, 'error' => 'دسترسی کاربر مورد نیاز است'], 401);
        }
        
        return $user;
    }
    
   public function jsonResponse($data, $statusCode = 200) {
		http_response_code($statusCode);
		header('Content-Type: application/json; charset=utf-8');
		echo json_encode($data, JSON_UNESCAPED_UNICODE);
		exit;
	}
    
    public function logAction($action, $details = '') {
        $logFile = ABSPATH . 'logs/api_actions.log';
        $logDir = dirname($logFile);
        
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $timestamp = date('Y-m-d H:i:s');
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $logMessage = "[$timestamp] [$ip] $action";
        
        if ($details) {
            $logMessage .= " - $details";
        }
        
        $logMessage .= PHP_EOL;
        file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);
    }
}
?>