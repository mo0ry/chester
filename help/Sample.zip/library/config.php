<?php
// مسیر اصلی
if (!defined('ABSPATH')) {
    define('ABSPATH', dirname(__DIR__) . '/');
}

// تنظیمات پایگاه داده
define('DB_HOST', 'localhost');
define('DB_NAME', 'license_system');
define('DB_USER', 'root');
define('DB_PASS', '');

// تنظیمات امنیتی
define('SECRET_KEY', 'your-secret-key-here-change-this-in-production');
define('TOKEN_EXPIRY', 3600); // 1 hour
define('TOKEN_EXPIRY_HOURS', 24); // 24 hours
define('PASSWORD_HASH_COST', 12);

// تنظیمات لایسنس
define('DEFAULT_TRIAL_DAYS', 30);
define('MAX_TRIAL_DAYS', 3650);

// تنظیمات API
define('API_VERSION', '1.0.0');

// حالت توسعه
define('DEBUG_MODE', true);

// توابع کمکی
function generateToken($length = 32) {
    return bin2hex(random_bytes($length));
}

function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => PASSWORD_HASH_COST]);
}

function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}
?>