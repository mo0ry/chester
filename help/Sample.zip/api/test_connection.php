<?php
$loader->jsonResponse([
    'success' => true,
    'message' => 'API is working',
    'timestamp' => date('Y-m-d H:i:s'),
    'version' => '1.0.0'
]);
?>