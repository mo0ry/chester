<?php
$input = json_decode(file_get_contents('php://input'), true) ?? [];

define('ABSPATH', dirname(__DIR__) . '/');
require_once '../library/loader.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// مدیریت CORS preflight
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit(0);
}

$loader = new Loader();
$page = $_GET['pages'] ?? 'test_connection';

// لیست endpoint های مجاز
$allowedEndpoints = [
    'user_login', 
    'test_connection'
];

// بررسی وجود endpoint
if (!in_array($page, $allowedEndpoints)) {
    $loader->jsonResponse([
        'success' => false,
        'error' => 'Endpoint یافت نشد: ' . $page
    ], 404);
}

// بارگذاری فایل endpoint
$endpointFile = __DIR__ . '/' . $page . '.php';
if (!file_exists($endpointFile)) {
    $loader->jsonResponse([
        'success' => false,
        'error' => 'فایل endpoint یافت نشد: ' . $page
    ], 404);
}

try {
    require_once $endpointFile;
} catch (Exception $e) {
    $loader->jsonResponse([
        'success' => false,
        'error' => 'خطا در اجرای endpoint: ' . $e->getMessage()
    ], 500);
}
?>