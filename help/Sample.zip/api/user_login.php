<?php

if (!isset($input['username']) || !isset($input['password'])) {
    $loader->jsonResponse([
        'success' => false, 
        'error' => 'نام کاربری و رمز عبور الزامی است'
    ]);
}

$userManager = new UserManager();
$user = $userManager->verifyUser($input['username'], $input['password']);

if (!$user) {
    $loader->logAction('USER_LOGIN_FAILED', "Username: {$input['username']}");
    $loader->jsonResponse([
        'success' => false, 
        'error' => 'نام کاربری یا رمز عبور اشتباه است'
    ]);
}

// بررسی انقضای قرارداد
$remainingDays = $userManager->getRemainingDays($user['id']);
if ($remainingDays <= 0) {
    $loader->jsonResponse([
        'success' => false, 
        'error' => 'قرارداد شما منقضی شده است'
    ]);
}

$token = $userManager->createUserToken($user['id']);

if (!$token) {
    $loader->jsonResponse([
        'success' => false, 
        'error' => 'خطا در ایجاد توکن'
    ]);
}

$loader->logAction('USER_LOGIN_SUCCESS', "Username: {$user['username']}");

$loader->jsonResponse([
    'success' => true,
    'token' => $token,
    'user' => [
        'id' => $user['id'],
        'username' => $user['username'],
        'company_name' => $user['company_name'],
        'max_computers' => $user['max_computers'],
        'contract_start' => $user['contract_start'],
        'contract_end' => $user['contract_end'],
        'remaining_days' => $remainingDays
    ]
]);
?>